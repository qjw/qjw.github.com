---
layout: post
title:  给Jekeyll添加评论系统
category: www
---
         
1. 打开[Disqus](http://disqus.com/),并注册帐号
2. 登录之后，点击"Get this on your site"
3. 打开新界面之后，配置"网址","帐号"等信息后，打开网址<http://disqus.com/admin/universal/>
4. 按照提示将生成的代码嵌入到你希望显示的地方，我放在"_layouts/post.html的最下面"

##参考
1. <http://help.disqus.com/customer/portal/articles/472138-jekyll-installation-instructions>
1. <http://disqus.com/admin/universal/>