---
layout: post
title:  解决Google Earth 不能查看照片的bug
category: other
---

打开文件**C:\Windows\system32\drivers\etc\hosts**

在后面添加以下dns

	173.194.72.141 www.panoramio.com
	173.194.64.141 www.panoramio.com
	74.125.71.113 www.panoramio.com
	173.194.77.141 www.panoramio.com
	173.194.76.141 www.panoramio.com
	74.125.65.141 www.panoramio.com
	173.194.74.141  www.panoramio.com
			
##参考
1. <http://blog.sina.com.cn/s/blog_62f9fade010127c1.html>		