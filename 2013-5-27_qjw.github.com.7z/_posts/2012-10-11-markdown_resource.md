---
layout: post
title: Markdown学习资料
category: www
---
###相关网址
* markdown在线编辑器 [http://dillinger.io/](http://dillinger.io/)
* [Markdown 简洁入门](http://www.fookwood.com/archives/639)
* [Markdown 简介](http://name5566.com/2989.html)

###参考文献列表
* [http://daringfireball.net/projects/markdown/](http://daringfireball.net/projects/markdown/)
* [http://www.867game.com/news/nr_index_5296.html](http://en.wikipedia.org/wiki/Markdown)
