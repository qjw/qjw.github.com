---
layout: post
title: WTL免费开发环境
category: wtl
---

##VC++ Express 2008 English
（不要用中文，以免codelite输出乱码）

<http://download.microsoft.com/download/e/8/e/e8eeb394-7f42-4963-a2d8-29559b738298/VS2008ExpressWithSP1ENUX1504728.iso>


##Windows SDK 6.1
<http://download.microsoft.com/download/f/e/6/fe6eb291-e187-4b06-ad78-bb45d066c30f/6.0.6001.18000.367-KRMSDK_EN.iso>


##Windows Driver Kit Version 7.1.0(wdk用于获取ATL的库/头文件)
<http://download.microsoft.com/download/4/A/2/4A25C7D5-EFBE-4182-B6A9-AE6850409A78/GRMWDK_EN_7600_1.ISO>


##WTL
1. <http://wtl.sourceforge.net/>
2. <http://nchc.dl.sourceforge.net/project/wtl/WTL%208.0/WTL%208.0%20Final/WTL80_7161_Final.zip>


##Codelite
1. <http://www.codelite.org/>
1. <http://sourceforge.net/projects/codelite/files/Releases/codelite-3.5/>
1. <http://nchc.dl.sourceforge.net/project/codelite/Releases/codelite-3.5/codelite-3.5.5377-mingw4.6.1.exe>


##CMake
（加入环境变量）

1. <www.cmake.org>
1. <http://ishare.iask.sina.com.cn/f/7204325.html>


##Cygwin
1. <http://cygwin.org/>
1. <http://cygwin.com/setup.exe>


##ResEdit
免费的资源编辑器，为兼容性考虑，建立下载ANSI版本的ResEdit。

1. <http://www.resedit.net/>
2. <http://www.resedit.net/ResEdit-win32.7z>
2. <http://www.resedit.net/ResEdit-x64.7z>


##VisualFC
WTL的应用程序向导,提供了单独的WTL80应用程序向导。

1. <http://code.google.com/p/visualfc/>
1. <http://visualfc.googlecode.com/files/WTLAppWizard2.01_rc1.zip>


##WTL程序开发插件VisualFC
最新的VisualFC0.8RC1提供了独立的VFCTool支持在VCExpress环境下WTL程序开发支持 

1. <http://code.google.com/p/visualfc/>
1. <http://visualfc.googlecode.com/files/VisualFC0.8RC1.zip>
1. <http://visualfc.googlecode.com/files/VFCAddin0.8RC1.msi>


